/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pr2.fel.cvut.cz.mariageapk;

/**
 *
 * @author Jiří
 */
public class Player{
    private static final int GAME_PRICE = 1;
    private static final int BETL_PRICE = 2;
    private static final int DURCH_PRICE = 3;
    private int id;
    String name;
    private Card[] deck = new Card[30];
    private Card playerCard[] = new Card[10];
    int cardCount = 0;
    int deckSize=0;
    boolean isBot;
    int coins;
    int trumpCount;
    int localTrumpCount;
    int trump;
    int localTrump;
    int yesOrNO=0;
    private Card[] talon = new Card[2];

    Player(String name, boolean isBot, int coins, int id) {
        this.id=id;
        this.name = name;
        this.isBot = isBot;
        this.coins = coins;
    }
    public void restart(int flek){
        deckSize=0;
        cardCount=0;
        if(!isBot && flek!=0) {
            for (int i = 0; i < 10; i++) {
                playerCard[i].setColor(playerCard[i].getColor() - 4);
            }
        }
    }

    public Card[] getDeck(){
        return deck;
    }

    public int getId(){
        return id;
    }

    public void trumpsCount(int localTrump){
        trumpCount=0;
        localTrumpCount=0;
        this.localTrump=localTrump;
        for(int i=0; i<cardCount; i++){
            if(playerCard[i].getColor()==trump) trumpCount++;
            if(playerCard[i].getColor()==localTrump) localTrumpCount++;
        }
    }

    public void setTrumps(int trump){
        this.trump=trump;
    }

    public Card[] getPlayerCards() {
        return playerCard;
    }

    public int getTrumpCount(){
        return trumpCount;
    }
    public int getLocalTrumpCount(){
        return localTrumpCount;
    }

    public void setYesOrNo(int i){
        yesOrNO=i;
    }

    public int getYesOrNo(){
        return yesOrNO;
    }

    public Card getPlayerCard(int num){
        return playerCard[num];
    }

    public void setPlayerCard(int num, Card card){
        playerCard[num]=card;
    }

    public int getCoins() {
        return coins;
    }

    public int getDeckSize(){
        return deckSize;
    }

    public void addToDeck(Card card) {
        deck[deckSize]=card;
        deckSize++;
    }

    public Card setCard() {
        int a = (int) (Math.random() * cardCount);
        Card temp=playerCard[a];
        playerCard[a]=playerCard[cardCount-1];
        cardCount--;
        return temp;
    }

    public Card setCard(int localTrump) {
        this.localTrump=localTrump;
        trumpsCount(localTrump);
        int a = (int) (Math.random() * cardCount);

        if(trumpCount>0){
            for(int i=0; i<cardCount; i++){
                if(playerCard[i].getColor()==trump) {
                    a=i;
                    break;
                }
            }
        }
        if(localTrumpCount>0){
            for(int i=0; i<cardCount; i++){
                if(playerCard[i].getColor()==localTrump) {
                    a=i;
                    break;
                }
            }
        }
        Card temp = playerCard[a];
        playerCard[a]=playerCard[cardCount-1];
        cardCount--;
        return temp;
    }

    public void addCard(Card card) {
        playerCard[cardCount]=card;
        cardCount++;
    }
    public String getName(){
        return name;
    }

    public Card getTalonCard(int num){
        return talon[num];
    }

    public void setTalonCard(int num, Card card){
        talon[num] = card;
    }

    public int scoreOfGame() {
        int score = 0;
        for (int i = 0; i < deckSize; i++) {
            if (deck[i].getValue() == 10) {
                score += 10;
            } else if (deck[i].getValue() == 14) {
                score += 10;
            }
        }
        return score;
    }

    public boolean isBot() {
        return isBot;
    }

    public Card getDeckCard(int i){
        return deck[i];
    }

    public int pay(Player player, int flek, int game) {
        int main = 0;
        switch (game) {
            case 0:
                main = GAME_PRICE;
                break;
            case 1:
                main = BETL_PRICE;
                break;
            case 2:
                main = DURCH_PRICE;
                break;
            default:
                main = GAME_PRICE;
        }
        int num = (int) (main * (Math.pow(2, flek)));
        if (num > coins) {
            num = coins;
        }
        decreaseCoins(num);
        player.increaseCoins(num);
        return num;
    }

    public void increaseCoins(int num) {
        this.coins = coins + num;
    }

    public void decreaseCoins(int num) {
        this.coins = coins - num;
    }

    public Card[] setTalon(Card[] talon) {
        this.talon = talon;
        if (isBot) {
            for (int i = 0; i < 2; i++) {
                int num = (int) (Math.random() * 10);
                Card temp = playerCard[num];
                playerCard[num]= talon[i];
                talon[i] = temp;
            }
        }
        return talon;
    }

    public void setCardCount(int cardCount) {
        this.cardCount = cardCount;
    }

    public int chooseTrumfs() {
        int trumfs = 0;
        trumfs = (int) (Math.random() * 4);
        return trumfs;
    }

    public int flek() {
        int flek = 0;
            int fl = (int) (Math.random() * 3);
            if (fl < 2) {
                flek = 1;
            } else {
                flek = 0;
            }

        return flek;
    }
    public int licitate(int level) {
            int maxProbability = 0;
            switch (level) {
                case 0:
                    maxProbability = 100;
                    break;
                case 1:
                    maxProbability = 85;
                    break;
                case 2:
                    maxProbability = 70;
                    break;
                default:
                    maxProbability = 50;
            }
            double probability = Math.random() * maxProbability;
            if (probability > 50) {
                return 1;
            } else {
                return 0;
            }
    }

    public Card[] removeDeck(Card[] card, int h) {
        int half = h;
        Card[] firstHalf = new Card[half];
        Card[] secondHalf = new Card[32 - half];
        for (int i = 0; i < half; i++) {
            firstHalf[i] = card[i];
        }
        int temp = 0;
        for (int i = half; i < card.length; i++) {
            secondHalf[temp] = card[i];
            temp++;
        }
        for (int i = 0; i < secondHalf.length; i++) {
            card[i] = secondHalf[i];
        }
        temp = 0;
        for (int i = secondHalf.length; i < card.length; i++) {
            card[i] = firstHalf[temp];
            temp++;
        }
        half = 0;
        return card;
    }

    @Override
    public String toString() {
        String str = "";
        str += name + " \n";
        return str;
    }
}
